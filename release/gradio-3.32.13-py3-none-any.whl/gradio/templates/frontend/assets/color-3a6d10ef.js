import{ao as o}from"./index-f87b526f.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color-3a6d10ef.js.map
