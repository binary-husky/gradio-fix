import{F as p}from"./Form-1d1f6a20.js";import"./index-f87b526f.js";const t=["static"];export{p as Component,t as modes};
//# sourceMappingURL=index-be06b001.js.map
