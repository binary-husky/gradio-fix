import{C as e}from"./Column-cd079490.js";import"./index-f87b526f.js";/* empty css                                             */const m=["static"];export{e as Component,m as modes};
//# sourceMappingURL=index-ccaf09aa.js.map
