import{a1 as s}from"./index-f87b526f.js";const o=["static"];export{s as Component,o as modes};
//# sourceMappingURL=index-6c264a90.js.map
