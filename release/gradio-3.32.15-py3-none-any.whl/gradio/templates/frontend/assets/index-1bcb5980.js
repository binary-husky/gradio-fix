import{F as p}from"./Form-cec1124e.js";import"./index-e83498d5.js";const t=["static"];export{p as Component,t as modes};
//# sourceMappingURL=index-1bcb5980.js.map
