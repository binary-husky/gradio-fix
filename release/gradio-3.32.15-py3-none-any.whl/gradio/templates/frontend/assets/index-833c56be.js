import{C as e}from"./Column-c1e54376.js";import"./index-e83498d5.js";/* empty css                                             */const m=["static"];export{e as Component,m as modes};
//# sourceMappingURL=index-833c56be.js.map
