import{ao as o}from"./index-e83498d5.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color-d9afdbe0.js.map
