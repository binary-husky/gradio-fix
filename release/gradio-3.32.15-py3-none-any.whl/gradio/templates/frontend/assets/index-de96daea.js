import{a1 as s}from"./index-e83498d5.js";const o=["static"];export{s as Component,o as modes};
//# sourceMappingURL=index-de96daea.js.map
