import{C as e}from"./Column-1efb67c3.js";import"./index-b94681d5.js";/* empty css                                             */const m=["static"];export{e as Component,m as modes};
//# sourceMappingURL=index-cc7fe2ab.js.map
