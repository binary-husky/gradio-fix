import{ao as o}from"./index-b94681d5.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color-d3eb52e3.js.map
