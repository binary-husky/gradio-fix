import{a1 as s}from"./index-b94681d5.js";const o=["static"];export{s as Component,o as modes};
//# sourceMappingURL=index-d04a8071.js.map
