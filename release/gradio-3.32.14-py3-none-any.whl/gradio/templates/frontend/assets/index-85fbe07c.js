import{F as p}from"./Form-e5e3135f.js";import"./index-b94681d5.js";const t=["static"];export{p as Component,t as modes};
//# sourceMappingURL=index-85fbe07c.js.map
